

Dockerfile 和 Nginx 代码基于 [docker-nginx-react](https://github.com/zzswang/docker-nginx-react)