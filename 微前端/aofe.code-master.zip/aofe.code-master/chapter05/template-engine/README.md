字符串模板引擎
===


相关开源项目

 - [https://github.com/trix/nano](https://github.com/trix/nano) 不到 10 行的模板引擎示例
 - [https://github.com/blueimp/JavaScript-Templates](https://github.com/blueimp/JavaScript-Templates) 不到 100 行的轻量级的模板引擎
 - [mustache.js](https://github.com/janl/mustache.js/) 模板引擎
 - [handlebars.js](https://github.com/wycats/handlebars.js/) 模板引擎
