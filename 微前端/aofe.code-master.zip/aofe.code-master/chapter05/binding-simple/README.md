# 简单的双向绑定示例

原始代码：[https://github.com/SantiagoGdaR/js-two-way-binding](https://github.com/SantiagoGdaR/js-two-way-binding)


相关资源
---

 - [剖析Vue实现原理 - 如何实现双向绑定mvvm](https://github.com/DMQ/mvvm)
 - [Rivets](https://github.com/mikeric/rivets) 一个轻量级的双向绑定库

 
