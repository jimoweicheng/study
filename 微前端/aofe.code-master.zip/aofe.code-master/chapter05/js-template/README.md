相关项目：[WINV](https://github.com/phodal/winv)

模板：

```html
<view class="container"><text class="user-motto">{{motto}}</text></view>
```

```
winv.setTemplate('<view class="container"><text class="user-motto">{{motto}}</text></view>')
```

相关资源：


Example, sorting https://jsfiddle.net/chefk6uu/
increase, decrease and revert.
But, I found simple solution: https://jsfiddle.net/m6365sc6/


Virtual DOM 算法：


1. https://github.com/livoras/simple-virtual-dom

Virtual DOM 库：

1. https://github.com/trueadm/t7
2. https://github.com/WebReflection/hyperHTML
