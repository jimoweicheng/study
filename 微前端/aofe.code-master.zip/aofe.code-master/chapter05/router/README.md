路由
===




相关资源
---

轻量级客户端库：[Page.js](https://github.com/visionmedia/page.js)

 - [https://github.com/phodal/lettuce](https://github.com/phodal/lettuce)

相关文章
---

[Deep dive into client-side routing](http://krasimirtsonev.com/blog/article/deep-dive-into-client-side-routing-navigo-pushstate-hash)

[A modern JavaScript router in 100 lines](http://krasimirtsonev.com/blog/article/A-modern-JavaScript-router-in-100-lines-history-api-pushState-hash-url)
