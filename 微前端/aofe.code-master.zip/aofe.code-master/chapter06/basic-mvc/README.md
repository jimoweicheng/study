原始代码基于：[https://medium.com/@patrickackerman/classic-front-end-mvc-with-vanilla-javascript-7eee550bc702](https://medium.com/@patrickackerman/classic-front-end-mvc-with-vanilla-javascript-7eee550bc702)
