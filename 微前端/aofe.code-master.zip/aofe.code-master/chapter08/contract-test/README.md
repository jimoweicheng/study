# 契约测试

官方文档：

[Contract Test](https://spring.io/guides/gs/contract-rest/)

代码：

[Contact Test Code](https://github.com/spring-guides/gs-contract-rest)

[Pact](https://docs.pact.io/)

[Dredd](https://github.com/apiaryio/dredd)