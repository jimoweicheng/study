# GraphQL as BFF


```
query make {
  make(id: "2") {
    id,
    category,
    featured_image
  }
}
```
