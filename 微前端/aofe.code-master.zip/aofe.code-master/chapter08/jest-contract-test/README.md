# 前端契约测试


[Jest 契约测试示例](https://github.com/vnglst/mocking-with-jest)