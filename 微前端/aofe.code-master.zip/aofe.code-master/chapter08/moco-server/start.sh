#!/bin/sh

java -jar moco-runner-0.12.0-standalone.jar http -p 12306 -g config.json
