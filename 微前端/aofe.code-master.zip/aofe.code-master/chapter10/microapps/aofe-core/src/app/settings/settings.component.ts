import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-settings',
  template: '<p>settings<p>'
})
export class SettingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
