import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  template: '<p>settings<p>'
})
export class DashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
