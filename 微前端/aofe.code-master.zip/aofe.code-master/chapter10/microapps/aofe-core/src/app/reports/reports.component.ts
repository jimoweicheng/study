import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reports',
  template: '<p>reports<p>'
})
export class ReportsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
