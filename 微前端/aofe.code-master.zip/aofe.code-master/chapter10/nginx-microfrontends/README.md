基于 [https://github.com/GeoffSeloana/nginx-micro-frontends](https://github.com/GeoffSeloana/nginx-micro-frontends)
