微前端相关框架
===



 HTML 加载方案： [https://github.com/mnot/hinclude](https://github.com/mnot/hinclude)


### DDD 与事件风暴

[在微服务中使用领域事件](https://insights.thoughtworks.cn/use-domain-events-in-microservices/) 


[基于 webpack 的持久化缓存方案](https://github.com/pigcan/blog/issues/9)