export interface WidgetConfig {
    name: string;
    moduleBundlePath: string;
    moduleName: string;
}
