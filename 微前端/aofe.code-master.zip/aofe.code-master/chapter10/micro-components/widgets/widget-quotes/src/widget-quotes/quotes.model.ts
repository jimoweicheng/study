interface Quotes {
    contents: { quotes: { quote: string }[] };
}