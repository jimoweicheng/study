# MicroComponents

基于 [https://paucls.wordpress.com/2018/05/10/angular-pluggable-architecture/](https://paucls.wordpress.com/2018/05/10/angular-pluggable-architecture/)


