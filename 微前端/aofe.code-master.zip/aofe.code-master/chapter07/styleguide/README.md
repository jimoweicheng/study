Setup
===


```
npm install -g kss
```