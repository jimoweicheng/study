源码码：[https://github.com/phodal/wc-angular-demo](https://github.com/phodal/wc-angular-demo)
