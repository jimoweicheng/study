CH5
===

相关文章
---

### Style Guide

[“后台产品” UX & UI 设计总结（下）- Style Guide 制作](https://zhuanlan.zhihu.com/p/28809858)
[创建在线样式指南(living style guide): 案例分析](https://www.zcfy.cc/article/creating-a-living-style-guide-a-case-study-ndash-smashing-magazine)

### Design System

相关资源
---


### Style Guide

 - [http://styleguides.io/](http://styleguides.io/) 一个收集 Style Guide 的网站

### Design System 
 
 - [https://github.com/alexpate/awesome-design-systems](https://github.com/alexpate/awesome-design-systems)
 - [https://designsystemsrepo.com/](https://designsystemsrepo.com/)

#### Guidelines

 - Style Guidelines
 - UI Guidelines
 - Content Guide

#### 工具和相关资源

 - Designer Toolkit
 - Developer Toolkit
 - Vue Design System

#### 技术栈

Material Design 分离框架

 - 框架 Angular, React, and more
 - 软件管理
