```
npx create-react-app designsystem
```



```
npx -p @storybook/cli@rc sb init
```
